import React from 'react'

const page = () => {
  return (
    <div>
      Employee Dashboard
    </div>
  )
}

export default page
